# 尉迟公主 · 于阗（安卓壳）

仓库里放本工程（或上传这个 zip，配合 .github/workflows/main.yml 会自动解压并编译）。

1. 上传 zip 到仓库根目录（Add file → Upload files）
2. 确认 .github/workflows/main.yml 存在（Actions 页看到 build-apk 即可）
3. 等 Actions 跑完（绿勾）→ 在 Artifacts 里下载 yutian-apk
4. 解压得到 app-debug.apk，传到手机安装

游戏本体在 app/src/main/assets/www/index.html，完全离线，不需要任何权限。
